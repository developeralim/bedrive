export enum MenuPositions {
  DriveSidebar = 'drive-sidebar',
}
