import {RouteObject} from 'react-router';

export const appAdminRoutes: RouteObject[] = [];
